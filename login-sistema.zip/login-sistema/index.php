<?php
require_once __DIR__ . '/includes/auth.php';
requerirLogin();

switch (rolActual()) {
    case 'administrador':
        header('Location: dashboards/admin.php');
        break;
    case 'usuario':
        header('Location: dashboards/usuario.php');
        break;
    default:
        header('Location: login.php');
}
exit;
