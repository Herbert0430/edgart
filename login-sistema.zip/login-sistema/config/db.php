<?php
/**
 * Conexión a la base de datos usando PDO.
 * Configurado para XAMPP por defecto:
 *   host: localhost
 *   usuario: root
 *   password: '' (vacío por defecto en XAMPP)
 *   puerto: 3306
 */

$DB_HOST = 'localhost';
$DB_PORT = '3306';
$DB_NAME = 'sistema_login';
$DB_USER = 'root';
$DB_PASS = ''; // Si le pusiste contraseña a root en XAMPP, colócala aquí

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};port={$DB_PORT};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // En producción no muestres el error real al usuario final
    die('Error de conexión a la base de datos: ' . $e->getMessage());
}
