-- =========================================================
-- Base de datos: sistema_login
-- Ejecutar este script en phpMyAdmin (XAMPP) o en la consola MySQL
-- =========================================================

CREATE DATABASE IF NOT EXISTS sistema_login
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sistema_login;

-- ---------------------------------------------------------
-- Tabla: roles
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre_rol VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO roles (nombre_rol) VALUES
  ('administrador'),
  ('usuario')
ON DUPLICATE KEY UPDATE nombre_rol = VALUES(nombre_rol);

-- ---------------------------------------------------------
-- Tabla: usuarios
-- El login se hace con "carnet" (número de carnet) + password
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  carnet VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(255) NULL,             -- opcional: ver nota de seguridad abajo
  rol_id INT NOT NULL,
  estado TINYINT(1) NOT NULL DEFAULT 1,   -- 1 = activo, 0 = bloqueado
  intentos_fallidos INT NOT NULL DEFAULT 0,
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (rol_id) REFERENCES roles(id)
);

-- ---------------------------------------------------------
-- NOTA DE SEGURIDAD:
-- Este login valida solo por "nombre" + "carnet", tal como se pidió.
-- Esto es cómodo para sistemas internos (ej. control de asistencia,
-- votaciones, registros académicos) pero NO es seguro si el carnet
-- es un dato público o fácil de adivinar, porque cualquiera que
-- conozca el nombre y el carnet de otra persona podría iniciar
-- sesión como ella.
-- Si necesitas más seguridad, lo recomendable es agregar un campo
-- de contraseña (la columna "password" ya está lista para eso) y
-- validar con password_verify(). El código de login.php incluye
-- comentado cómo activarlo.
-- ---------------------------------------------------------

-- Usuarios de ejemplo
INSERT INTO usuarios (nombre, carnet, rol_id) VALUES
  ('Administrador General', '1000', (SELECT id FROM roles WHERE nombre_rol = 'administrador')),
  ('Juan Perez',            '2001', (SELECT id FROM roles WHERE nombre_rol = 'usuario'))
ON DUPLICATE KEY UPDATE nombre = VALUES(nombre);
