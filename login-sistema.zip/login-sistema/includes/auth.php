<?php
/**
 * Funciones de apoyo para autenticación y control de acceso por roles.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const MAX_INTENTOS_FALLIDOS = 5;

/** Verifica si hay una sesión activa */
function estaAutenticado(): bool
{
    return isset($_SESSION['usuario_id']);
}

/** Obtiene el rol del usuario en sesión (o null si no hay sesión) */
function rolActual(): ?string
{
    return $_SESSION['rol'] ?? null;
}

/**
 * Corta la ejecución si el usuario no ha iniciado sesión.
 * Úsalo al inicio de cualquier página protegida.
 */
function requerirLogin(): void
{
    if (!estaAutenticado()) {
        header('Location: ../login.php');
        exit;
    }
}

/**
 * Corta la ejecución si el usuario no tiene uno de los roles permitidos.
 * Ejemplo: requerirRol(['administrador']);
 */
function requerirRol(array $rolesPermitidos): void
{
    requerirLogin();
    if (!in_array(rolActual(), $rolesPermitidos, true)) {
        http_response_code(403);
        die('Acceso denegado: no tienes permisos para ver esta página.');
    }
}

/** Cierra la sesión actual */
function cerrarSesion(): void
{
    $_SESSION = [];
    session_destroy();
}
