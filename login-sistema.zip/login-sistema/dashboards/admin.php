<?php
require_once __DIR__ . '/../includes/auth.php';
requerirRol(['administrador']); // Solo administradores pueden ver esta página
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel de Administrador</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body style="display:block;">
  <div class="topbar">
    <span>Panel de Administrador — <?= htmlspecialchars($_SESSION['nombre']) ?> (Carnet: <?= htmlspecialchars($_SESSION['carnet']) ?>)</span>
    <a href="../logout.php">Cerrar sesión</a>
  </div>

  <div class="contenido">
    <h2>Bienvenido, administrador</h2>
    <p>Aquí puedes colocar la gestión de usuarios, reportes u otras funciones exclusivas del rol <strong>administrador</strong>.</p>
  </div>
</body>
</html>
