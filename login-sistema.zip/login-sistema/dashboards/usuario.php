<?php
require_once __DIR__ . '/../includes/auth.php';
requerirRol(['usuario', 'administrador']); // Usuario y admin pueden entrar aquí
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel de Usuario</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body style="display:block;">
  <div class="topbar">
    <span>Panel de Usuario — <?= htmlspecialchars($_SESSION['nombre']) ?> (Carnet: <?= htmlspecialchars($_SESSION['carnet']) ?>)</span>
    <a href="../logout.php">Cerrar sesión</a>
  </div>

  <div class="contenido">
    <h2>Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?></h2>
    <p>Este es tu panel como <strong>usuario</strong>. Aquí puedes mostrar la información o funciones que le correspondan a este rol.</p>
  </div>
</body>
</html>
