<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

// Si ya hay sesión activa, redirige directo a su panel
if (estaAutenticado()) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $carnet = trim($_POST['carnet'] ?? '');

    if ($nombre === '' || $carnet === '') {
        $error = 'Debes ingresar el nombre y el número de carnet.';
    } else {
        // Busca al usuario por carnet (clave única)
        $stmt = $pdo->prepare(
            'SELECT u.id, u.nombre, u.carnet, u.estado, u.intentos_fallidos, r.nombre_rol
             FROM usuarios u
             JOIN roles r ON r.id = u.rol_id
             WHERE u.carnet = :carnet
             LIMIT 1'
        );
        $stmt->execute(['carnet' => $carnet]);
        $usuario = $stmt->fetch();

        if (!$usuario) {
            $error = 'Nombre o número de carnet incorrectos.';
        } elseif ((int)$usuario['estado'] === 0) {
            $error = 'Este usuario está bloqueado. Contacta al administrador.';
        } elseif (mb_strtolower($usuario['nombre']) !== mb_strtolower($nombre)) {
            // El nombre debe coincidir exactamente con el registrado para ese carnet
            registrarIntentoFallido($pdo, $usuario['id'], $usuario['intentos_fallidos']);
            $error = 'Nombre o número de carnet incorrectos.';
        } else {
            // ------------------------------------------------------------
            // Si en el futuro agregas contraseña, reemplaza el bloque "else"
            // de arriba por una verificación con password_verify(), así:
            //
            //   if (!password_verify($_POST['password'], $usuario['password'])) {
            //       $error = 'Credenciales incorrectas.';
            //   } else { ... iniciar sesión ... }
            // ------------------------------------------------------------

            // Login correcto: reinicia intentos fallidos e inicia sesión
            $pdo->prepare('UPDATE usuarios SET intentos_fallidos = 0 WHERE id = :id')
                ->execute(['id' => $usuario['id']]);

            session_regenerate_id(true);
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre']     = $usuario['nombre'];
            $_SESSION['carnet']     = $usuario['carnet'];
            $_SESSION['rol']        = $usuario['nombre_rol'];

            header('Location: index.php');
            exit;
        }
    }
}

/** Incrementa intentos fallidos y bloquea la cuenta si supera el máximo */
function registrarIntentoFallido(PDO $pdo, int $usuarioId, int $intentosActuales): void
{
    $nuevosIntentos = $intentosActuales + 1;
    if ($nuevosIntentos >= MAX_INTENTOS_FALLIDOS) {
        $pdo->prepare('UPDATE usuarios SET intentos_fallidos = :i, estado = 0 WHERE id = :id')
            ->execute(['i' => $nuevosIntentos, 'id' => $usuarioId]);
    } else {
        $pdo->prepare('UPDATE usuarios SET intentos_fallidos = :i WHERE id = :id')
            ->execute(['i' => $nuevosIntentos, 'id' => $usuarioId]);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Iniciar sesión</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="card">
    <h1>Iniciar sesión</h1>

    <?php if ($error): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <label for="nombre">Nombre completo</label>
      <input type="text" id="nombre" name="nombre" required autofocus
             value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">

      <label for="carnet">Número de carnet</label>
      <input type="text" id="carnet" name="carnet" required
             value="<?= htmlspecialchars($_POST['carnet'] ?? '') ?>">

      <button type="submit">Ingresar</button>
    </form>
  </div>
</body>
</html>
